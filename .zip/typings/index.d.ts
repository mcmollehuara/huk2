/// <reference path="globals/vs/index.d.ts" />
