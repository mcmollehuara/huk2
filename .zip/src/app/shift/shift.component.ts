import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd} from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'shift-component',
    templateUrl: './shift.component.html'
})
export class ShiftComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}