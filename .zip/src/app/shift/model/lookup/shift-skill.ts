import { LookupMetadata } from './lookup-metadata';

export class Skill extends LookupMetadata {
    public imgUrl: string;

    public static dataDummy: Skill[] = [
        {
            "id": 1,
            "value": "Microsoft",
            "imgUrl": ""
        },
        {
            "id": 2,
            "value": "Network",
            "imgUrl": ""
        },
        {
            "id": 3,
            "value": "Unix/Linux",
            "imgUrl": ""
        },
        {
            "id": 4,
            "value": "Virtualization",
            "imgUrl": ""
        },
    ]
}   