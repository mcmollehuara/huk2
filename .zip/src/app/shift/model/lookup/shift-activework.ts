import { LookupMetadata } from './lookup-metadata';

export class ActiveWork extends LookupMetadata {
    public imgUrl: string;
    
    public static dataDummy: ActiveWork[] = [
        {
            "id": 1,
            "value": "Tickets",
            "imgUrl": ""
        },
        {
            "id": 2,
            "value": "Change Order",
            "imgUrl": ""
        }
    ]   
}