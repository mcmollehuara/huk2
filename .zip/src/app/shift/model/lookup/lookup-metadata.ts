export abstract class LookupMetadata{
    id: number;
    value: string;
}