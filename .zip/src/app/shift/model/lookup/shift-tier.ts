import { LookupMetadata } from './lookup-metadata';

export class Tier extends LookupMetadata {

    public static dataDummy: Tier[] = [
        {
            "id": 1,
            "value": "L1"
        },
        {
            "id": 2,
            "value": "L2"
        },
        {
            "id": 3,
            "value": "L3"
        }
    ]   
}