import { LookupMetadata } from './lookup-metadata';

export class Clearance extends LookupMetadata {

    public static dataDummy: Clearance[] = [
        {
            "id": 1,
            "value": "US only"
        },
        {
            "id": 2,
            "value": "Equilend"
        },
        {
            "id": 3,
            "value": "SSM"
        },
        {
            "id": 4,
            "value": "Ben-DNS"
        },
        {
            "id": 5,
            "value": "TFG027"
        },
        {
            "id": 6,
            "value": "TFG221"
        },
        {
            "id": 7,
            "value": "EWA"
        }
    ]    
}