import { LookupMetadata } from './lookup-metadata';

export class Availability extends LookupMetadata {
    public imgUrl: string;
    
    public static dataDummy: Availability[] = [
        {
            "id": 1,
            "value": "On Call",
            "imgUrl": ""
        },
        {
            "id": 2,
            "value": "On Shift",
            "imgUrl": ""
        },
        {
            "id": 3,
            "value": "On Vacations",
            "imgUrl": ""
        },
        {
            "id": 4,
            "value": "Absent",
            "imgUrl": ""
        },
    ]
}