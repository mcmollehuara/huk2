export class Schedule {
    _id: string;
    entities: ScheduleEntity[];
    skills: ScheduleSkill[];
}

export class ScheduleEntity {
    entityType: string;
    entityName: string;
    counter: number
}

export class ScheduleSkill {
    skillId: number;
    skillName: string;
    entities: SkillEntity[];
    workForces: SkillWorkForce[];
    workloadAvailabilities: SkillAvailabilities[];
    profiles: SkillProfiles[];
}

export class SkillEntity {
    entityType: string;
    entityName: string;
    counter: number;
}

export class SkillWorkForce {
    skillId: number;
    startDate: Date;
    endDate: Date;
    totalUserOnShift: number;
    totalUserAbsent: number;
}

export class SkillAvailabilities {
    skillId: number;
    startDate: Date;
    endDate: Date;
    type: number;
}

export class SkillProfiles {
    profileID: number;
    vzid: string;
    firstName: string;
    secondName: string;
    jabberStatus: string;
    tierId: number;
    tierName: string;
    clearanceId: number;
    clearanceName: string;
    activeWorks: ProfileActiveWork[];
    availabilities:ProfileAvailabilities[];
}

export class ProfileActiveWork {
    vzid: string;
    entities: ProfileActiveWorkEntity[];
}

export class ProfileActiveWorkEntity {
    entityType: string;
    entityName: string;
    counter: number;
}

export class ProfileAvailabilities {
    vzid: string;
    startDate: Date;
    endDate: Date;
    type: number;

}

export class ShiftScheduleFilter {
    availabilityID: Array<number>;
    activeWork: Array<number>;
    skillID: Array<number>;
    tierID: Array<number>;
    clearanceID: Array<number>;
    startDate: Date;
    endDate: Date;
    directReport: boolean;
    vzManager: string;

}
// {
//     results:
//     {
//         entities:
//         [
//             { entityType: CLEARANCE, entityName: Equielend, counter: 2 },
//             { entityType: USER, entityName: USER, counter: 10 }
//         ]
//             ,
//             skills:[
//                 {
//                     skillId: 1,
//                     skillName: Network,
//                     entities: [
//                         { entityType: TK, entityName: TK, counter: 5 },
//                         { entityType: C0, entityName: C0, counter: 3 },
//                         { entityType: USER, entityName: USER, counter: 10 }],
//                     workForces: [
//                         { skillId: 1, startDate: 2016 - 10 - 20T07: 00:00, endDate: 2016 - 10 - 20T08: 00:00, totalUserOnShift: 2, totalUserAbsent: 2 },
//                         { skillId: 1, startDate: 2016 - 10 - 20T07: 00:00, endDate: 2016 - 10 - 20T08: 00:00, totalUserOnShift: 1, totalUserAbsent: 2 }],
//                     workloadAvailabilities: [
//                         { skillId: 1, startDate: 2016 - 10 - 20T07: 00:00, endDate: 2016 - 10 - 20T12: 00:00, type: 1 },
//                         { skillId: 1, startDate: 2016 - 10 - 20T07: 00:00, endDate: 2016 - 10 - 20T12: 00:00, type: 2 }],
//                     profiles: [
//                         {
//                             profileID: 1, vzid: VZ531761, firstName: Morales, secondName: Flor, jabberStatus: Active, tierId: 1, tierName: L1, clearanceId: 1, clearanceName: TFG27,
//                             activeWorks: [
//                                 {
//                                     vzid: VZ531761, entities: [
//                                         { entityType: TK, entityName: TK, counter: 5 }, { entityType: C0, entityName: C0, counter: 3 }]
//                                 }],
//                             availabilities: [
//                                 { vzid: VZ531761, startDate: 2016 - 10 - 20T07: 00:00, endDate: 2016 - 10 - 20T12: 00:00, type: 1 }
//                             ]
//                         }]
//                 }
//             ]
//     }
// }