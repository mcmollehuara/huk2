import { ModuleWithProviders }  from '@angular/core';
import {Routes,  RouterModule } from '@angular/router';
import { ShiftComponent } from './shift.component';
import {LayoutComponent} from '../layout/layout.component';

const routes: Routes = [{
    path:'shift',
    component: LayoutComponent,
    children:[
      { path: 'schedule', component: ShiftComponent}
    ]
  }];


export const appRoutingProviders: any[] = [];

  export const ShiftRoutes : ModuleWithProviders=RouterModule.forChild(routes);
