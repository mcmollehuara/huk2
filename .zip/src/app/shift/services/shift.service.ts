import { Injectable } from '@angular/core';
import { Http, Response, Headers} from '@angular/http';
import { Observable } from 'rxjs/Observable';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

import {Clearance, Skill, Tier, ActiveWork, Availability} from './../model/index';
declare let apiConfig: any;


@Injectable()
export class ShiftService {
    _apiRootUri: string;
    constructor(private http: Http) { 
        this._apiRootUri = apiConfig.shift;

        //===============================================
        // [[   TODO: Data Dummy  ]]
        this._availabilityList = Availability.dataDummy;
        this._skillList = Skill.dataDummy;
        this._tierList = Tier.dataDummy;
        this._activityWorkList = ActiveWork.dataDummy;
        this._clearanceList = Clearance.dataDummy;
        //===============================================
    }

    private _availabilityList: Availability[];
    private _skillList: Skill[];
    private _tierList: Tier[];
    private _activityWorkList: ActiveWork[];
    private _clearanceList: Clearance[];
    

    public getSkills(filter: string): Promise<any> {
        return this.http.post(
            this._apiRootUri + '/lookup/skills'
            , filter
            //,{headers: this.loginService.addAutorizationHeader(new Headers())}            
        ).map((res: Response) => {
            let objJSON = res.json();            
            var lstObj = new Array();
            lstObj = this._skillList;           
            /*
            for (var index = 0; index < objJSON.queries.length; index++) {
                let _item = new Skill();
                _item.id = objJSON.queries[index].SkillID;
                _item.value = objJSON.queries[index].Name;
                lstObj[index] = _item;
            }            
            */    
            return lstObj;

        }).toPromise();
    }

    public getClearance(filter: string): Promise<any> {
        return this.http.post(
            this._apiRootUri + '/lookup/clearance'
            , filter
            //,{headers: this.loginService.addAutorizationHeader(new Headers())}            
        ).map((res: Response) => {
            let objJSON = res.json();            
            var lstObj = new Array();
            lstObj = this._clearanceList;
            /*
            for (var index = 0; index < objJSON.queries.length; index++) {
                let _item = new Clearance();
                _item.id = objJSON.queries[index].ClearanceID;
                _item.value = objJSON.queries[index].Name;
                lstObj[index] = _item;
            }            
            */
            return lstObj;
        }).toPromise();        
    }

    public getTier(filter: string): Promise<any> {
        return this.http.post(
            this._apiRootUri + '/lookup/tier'
            , filter
            //,{headers: this.loginService.addAutorizationHeader(new Headers())}            
        ).map((res: Response) => {
            let objJSON = res.json();            
            var lstObj = new Array();
            lstObj = this._tierList;
            /*
            for (var index = 0; index < objJSON.queries.length; index++) {
                let _item = new Tier();
                _item.id = objJSON.queries[index].TierID;
                _item.value = objJSON.queries[index].Name;
                lstObj[index] = _item;
            }            
            */
            return lstObj;
        }).toPromise();        
    }

    public getActiveWork(filter: string): Promise<any> {
        return this.http.post(
            this._apiRootUri + '/lookup/activework'
            , filter
            //,{headers: this.loginService.addAutorizationHeader(new Headers())}            
        ).map((res: Response) => {
            let objJSON = res.json();            
            var lstObj = new Array();
            lstObj = this._activityWorkList;
            /*
            for (var index = 0; index < objJSON.queries.length; index++) {
                let _item = new ActiveWork();
                _item.id = objJSON.queries[index].ActiveWorkID;
                _item.value = objJSON.queries[index].Name;
                lstObj[index] = _item;
            }            
            */
            return lstObj;
        }).toPromise();        
    }

    public getAvailability(filter: string): Promise<any> {
        return this.http.post(
            this._apiRootUri + '/lookup/availability'
            , filter
            //,{headers: this.loginService.addAutorizationHeader(new Headers())}            
        ).map((res: Response) => {
            let objJSON = res.json();            
            var lstObj = new Array();
            lstObj = this._availabilityList;
            /*
            for (var index = 0; index < objJSON.queries.length; index++) {
                let _item = new Availability();
                _item.id = objJSON.queries[index].AvailabilityID;
                _item.value = objJSON.queries[index].Name;
                lstObj[index] = _item;
            }            
            */
            return lstObj;
        }).toPromise();        
    }
}