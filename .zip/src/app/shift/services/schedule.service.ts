import { Injectable, Inject } from '@angular/core';
import { Http, Response, Headers} from '@angular/http';
import { Observable } from 'rxjs/Observable';
// import { ShiftScheduleFilter } from './../model/shift-schedule.model';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ScheduleService {
    _apiRootUri: string;
    constructor(private http: Http) {
        this._apiRootUri = 'https://sdp-dev.terremark.net/Oss.ResourceManager/';
        //  this._apiRootUri = 'http://localhost:54492/';
    }

    public getShiftResources(filters: any): Promise<any> {
        return this.http.post(
            this._apiRootUri + 'ShiftResource/GetShiftResources',
            filters
        ).map((res: Response) => {
            return res.json();
        }).toPromise();
    }
}