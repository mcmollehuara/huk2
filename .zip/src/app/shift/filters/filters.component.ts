import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { Router, NavigationEnd} from '@angular/router';


import { Tier } from './services/tier';
import { ActiveWork } from './services/active-work';
import { Availability } from './services/availability';
import { Skill } from './services/skill';
import { Cleareance } from './services/cleareance';

import { Filters } from './services/filters';

import { FiltersService } from './services/filters.service';


@Component({
    moduleId: module.id,
    selector: 'shift-filters',
    templateUrl: './shift-filters.component.html',
    styleUrls:  ['filters.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [FiltersService]
})
export class ShiftFiltersComponent implements OnInit {

    tiers: Tier[];
    skills: Skill[];
    activeWorks: ActiveWork[];
    cleareances: Cleareance[];
    availabilities: Availability[];

    constructor(
        private filtersService: FiltersService
        ) { }

    ngOnInit() { 
        this.getFilters();
    }

    get diagnostic() { return JSON.stringify(this.tiers); }

    getFilters(): void {

        this.filtersService.getFilters().then(x=> {
            this.skills = x.skills;
            this.availabilities = x.availabilities;
            this.tiers = x.tiers;
            this.activeWorks = x.activeWorks;
            this.cleareances = x.cleareances;
        });

        this.filtersService.getFilters().then(x=> {
            this.skills = x.skills;

            this.skills.forEach(element => {
                if(element.name=='Microsoft') element.icon_class = 'fa fa-windows';
                if(element.name=='Network') element.icon_class = 'fa fa-sitemap';
                if(element.name=='UNIX/Linux') element.icon_class = 'fa fa-linux';
                if(element.name=='Virtualization') element.icon_class = 'fa fa-cloud';
            });
              

            this.availabilities = x.availabilities;

            this.availabilities.forEach(element => {
                if(element.name=='On Shift') element.state = true;
                if(element.name=='Absent') element.state = true;
            });

            this.tiers = x.tiers;
            this.activeWorks = x.activeWorks;
            this.cleareances = x.cleareances;
        });
    }

    private logCheckbox(): void {
       
    }
}