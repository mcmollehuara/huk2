export class Availability {
    

constructor(
    public id: number,
    public name: string, public state:Boolean) { }
}