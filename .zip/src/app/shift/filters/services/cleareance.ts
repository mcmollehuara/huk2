export class Cleareance {
    public state:boolean;
constructor(
    public id: number,
    public name: string) { }
}