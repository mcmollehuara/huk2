export class Tier {
  public state:boolean;

  constructor(
    public id: number,
    public name: string) { }
}