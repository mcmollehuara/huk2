import { Availability } from './availability';
import { ActiveWork } from './active-work';
import { Skill } from './skill';
import { Cleareance } from './cleareance';
import { Tier } from './tier';


export class Filters {

  constructor(
    public availabilities: Availability[],
    public skills: Skill[],
    public cleareances: Cleareance[],
    public tiers: Tier[],
    public activeWorks: ActiveWork[]) { }
}

 