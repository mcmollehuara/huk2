export class Skill {
  public state:boolean;

  constructor(
    public skillId: number,
    public name: string,
    public icon_class:string) { }
}

 