import { Skill } from './skill';
// export const SKILLS: Skill[] = [
//   {skillId: 1, name: 'Microsoft', icon_class: 'fa fa-windows'},
//   {skillId: 2, name: 'Network', icon_class: 'fa fa-sitemap'},
//   {skillId: 3, name: 'Unix/Linux', icon_class: 'fa fa-linux'},
//   {skillId: 3, name: 'Virtualization', icon_class: 'fa fa-cloud'}
// ];

// export const SKILLS: Skill[] = [
//   {id: 1, name: 'Microsoft', icon_class: 'fa fa-windows'},
//   {id: 2, name: 'Network', icon_class: 'fa fa-sitemap'},
//   {id: 3, name: 'Unix/Linux', icon_class: 'fa fa-linux'},
//   {id: 3, name: 'Virtualization', icon_class: 'fa fa-cloud'}
// ];