import { Component, OnInit ,ViewEncapsulation,Input} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'shift-profile',
    templateUrl: './shift-profile.component.html',
    encapsulation: ViewEncapsulation.None
})
export class ShiftProfileComponent implements OnInit {
    @Input() name: string;
    constructor() { }

    ngOnInit() { }
}