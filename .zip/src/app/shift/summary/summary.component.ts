import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'shift-summary',
    templateUrl: './shift-summary.component.html'
})
export class ShiftSummaryComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}