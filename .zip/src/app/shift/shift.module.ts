import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';

import { FormsModule }   from '@angular/forms';
import { RouterModule }  from '@angular/router';

// import 'ng2-datetime/src/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js';
// import 'ng2-datetime/src/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js';

import { ShiftService } from './services/shift.service';
import { ScheduleService} from './services/schedule.service';
import { ShiftComponent }   from './shift.component';
import { ShiftRoutes }   from './shift.routes';
import { ShiftScheduleComponent }   from './schedule/schedule.component';
import { ShiftFiltersComponent }   from './filters/filters.component';
import { ShiftSummaryComponent }   from './summary/summary.component';
import { ShiftProfileComponent }   from './profile/profile.component';

// import { NKDatetimeModule } from 'ng2-datetime/ng2-datetime';

@NgModule({
    imports: [BrowserModule, FormsModule, RouterModule, ShiftRoutes],
    exports: [],
    declarations: [ShiftComponent, ShiftScheduleComponent, ShiftFiltersComponent,ShiftSummaryComponent,ShiftProfileComponent],
    providers: [ShiftService, ScheduleService],
})
export class ShiftModule { }
