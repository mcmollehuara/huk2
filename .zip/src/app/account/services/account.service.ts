import { Injectable } from '@angular/core';

@Injectable()
export class accountService {

    constructor() { }

    /**
     * login
     */
    public login() {
        
    }

}