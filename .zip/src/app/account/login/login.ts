import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import { Router} from '@angular/router';
@Component({
    // moduleId: module.id,
    selector: '[login]',
    host: { class: 'login-page app' },
    templateUrl: './login.html',
    encapsulation: ViewEncapsulation.None
})
export class LoginPage implements OnInit {
    model: any = {};

    constructor(private router: Router) {

    }

    ngOnInit() {
    }

    login() {
        this.router.navigate(['app/shift/schedule']);        
    }
}
