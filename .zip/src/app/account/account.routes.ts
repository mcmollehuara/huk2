import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPage } from './login/login';

const routes: Routes = [
  { path: 'login',  component: LoginPage }
];

export const AccountRoutes: ModuleWithProviders = RouterModule.forChild(routes);
