import { Routes, RouterModule } from '@angular/router';
import { DataResolver } from './app.resolver';
import { LoginPage } from './account/login/login';
import { ShiftComponent } from './shift/shift.component';


export const AppRoutes: Routes = [
  // { path: 'login', component: LoginPage },
  { path: '**', redirectTo: 'shift/schedule'},
  // {
  //   path: 'profile', loadChildren: () => System.import('./profile')
  // },
];
