
import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'shared-component',
    templateUrl: 'feature.component.html'
})
export class SharedComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}