import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'profile-component',
    templateUrl: 'profile.html'
})
export class ProfileComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}