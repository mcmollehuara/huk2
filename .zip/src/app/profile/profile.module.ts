import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { ProfileComponent }   from './profile.component';

@NgModule({
    imports: [BrowserModule],
    exports: [],
    declarations: [ProfileComponent],
    providers: [],
})
export class ProfileModule { }
