export class UserInfo {

  constructor(
    public firstName: string,
    public lastName: string,
    public userName: string,
    public contactName: string
    ) { }
}

 