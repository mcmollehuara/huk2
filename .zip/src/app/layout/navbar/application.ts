export class Application {

  constructor(
    public applicationID: string,
    public applicationName: string,
    public defaultURL: string,
    public rootAppURL:string
    ) { }
}

 