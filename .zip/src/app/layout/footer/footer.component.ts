import {Component, OnInit} from '@angular/core';

@Component({
  selector: '[footer]',
  templateUrl: './footer.html'
})
export class FooterComponent {
  constructor() {
  }


}