import { Component, ElementRef } from '@angular/core';
import { Router, NavigationEnd} from '@angular/router';

@Component({
    selector: 'app-layout',
    providers: [],
    templateUrl: './layout.html'
})
export class LayoutComponent {

}