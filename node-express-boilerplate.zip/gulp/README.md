# Gulp Tasks

Task are separated by topic 

## Config.json

Contains configuration options for different tasks

## build.js

Build & build-related tasks

## watch.js

Watch tasks to trigger app recompilation, syncs development server.

## server.js

Contains browsersync-ready development server
