# Helper Libraries

## environment.js

CLI-wrapper module that enables retrieving/setting cli parameters to be used within the different tasks
 
## notifications.js

Adds a notification subpipe 

## events.js

Wrapper around node events for emitting / sending custom events