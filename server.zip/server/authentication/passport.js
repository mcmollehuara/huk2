//https://scotch.io/tutorials/easy-node-authentication-setup-and-local
class PassportConfiguration {
    constructor(passport) {
        var LocalStrategy = require('passport-local').Strategy;
        var FacebookStrategy = require('passport-facebook').Strategy;
        var UserDA = require('../data').UserDA;
        var config = require('config');
        var facebook_config = config.get("facebook");

        var emailcomponent = require('../component/emailDispatch');

        passport.serializeUser((user, done) => {
            done(null, user.id);
        });
        passport.deserializeUser((id, done) => {
            UserDA.getUserById(id, (err, user) => {
                done(err, user);
            });
        });

        passport.use('local-signup', new LocalStrategy({
            usernameField: 'email',
            passwordField: 'password',
            passReqToCallback: true
        },
            (req, email, password, done) => {
                UserDA.getByLocalEmail(email, (err, user) => {
                    if (err) {
                        return done(err);
                    }
                    if (user) {
                        return done(null, false, "El email ya esta siendo usado");
                    }
                    UserDA.createLocalUser(req.body, (err, newUser) => {
                        if (err) {
                            throw err;
                        }
                        console.log("before email");


                        var _user = {
                            id: newUser._id,
                            email: email,
                            first_name: newUser.firstName,
                            last_name: newUser.lastName,
                            url: config.get("siteInfo").url,
                            encrypted: req.body.encrypted
                        };

                        emailcomponent.sendNewUserMail(_user, email, true);
                        console.log("after email");
                        return done(null, { id: newUser._id, email: email, name: newUser.firstName + " " + newUser.lastName });
                    });
                });
            }));

        passport.use('local-login', new LocalStrategy({
            usernameField: 'email',
            passwordField: 'password',
            passReqToCallback: true
        },
            (req, email, password, done) => {
                UserDA.getByLocalEmail(email, (err, user) => {
                    if (err) {
                        return done(err);
                    }
                    if (!user) {
                        return done(null, false, 'Email or Password invalid');
                    }

                    var validatePassword = UserDA.validateUserPassword(password, user.local.password);

                    if (validatePassword) {
                        return done(null, { id: user._id, email: email });
                    }

                    return done(null, false, 'Email or Password invalid');
                });
            }));

        passport.use(new FacebookStrategy({
            clientID: facebook_config.clientID,
            clientSecret: facebook_config.clientSecret,
            callbackURL: facebook_config.callbackURL,
            profileFields: ['email', 'first_name', 'gender', 'last_name', 'middle_name', 'timezone', 'picture']
        }, (token, refreshToken, profile, done) => {
            console.log("facebook...", token, refreshToken, profile);
            process.nextTick(() => {

                var email = profile.id + "@facebook.com";
                if (profile.emails && profile.emails[0])
                    email = profile.emails[0].value;

                UserDA.getByFacebookId(profile.id, (err, userFB) => {
                    if (err) {
                        return done(err);
                    }
                    //user doesn't exists                    
                    UserDA.getByEmail(email, (err, user) => {
                        if (err) {
                            return done(err)
                        }
                        if (user) {//return local user
                            user.token = token;
                            user.email = email;
                            UserDA.updateUser(user, token, profile._json)
                                .then(function (raw) {
                                    return done(null, { id: user._id, email: email });
                                }).catch(function (err) {
                                    return done(err)
                                });
                        } else {
                            if (userFB) {
                                //create user using fb account
                                userFB.token = token;
                                userFB.email = email;
                                UserDA.updateUser(userFB, token, profile._json)
                                    .then(function (raw) {
                                        return done(null, { id: userFB._id, email: email });
                                    }).catch(function (err) {
                                        return done(err)
                                    });
                            }
                            else {
                                UserDA.createFacebookUser(profile.id, token, email, profile.displayName, profile._json)
                                    .then(function (newUser) {
                                        // do not notify if fail
                                        emailcomponent.sendNewUserMail(newUser.facebook._json, email, (err) => { });
                                        return done(null, { id: newUser._id, email: email });
                                    }).catch(function (err) {
                                        return done(err)
                                    });
                            }
                        }
                    });
                })
            });
        }));
    }
}

module.exports = (passport) => {
    new PassportConfiguration(passport);
}