var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    path = require('path'),
    morgan = require('morgan'),
    cors = require('cors'),
    config = require('config');

require('babel-core/register')({
    presets: ['es2015', 'react']
})

var passport = require('passport');

var mongoose = require('mongoose');
mongoose.connect(config.get('mongo.db'));

//apidoc
app.use('/apidoc', express.static(path.join(__dirname, 'apidoc')));

var whitelist = config.get("cors.whitelist");
var corsOptions = {
    origin: function (origin, callback) {
        console.log(origin);
        var originIsWhitelisted = whitelist.indexOf(origin) !== -1;
        callback(null, originIsWhitelisted);
    }
};

app.use(cors(corsOptions));
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

require('./authentication/passport')(passport);

app.use(passport.initialize());
app.use(passport.session());

require('./router')(app, passport);

// app.use(function (req, res) {
//     res.sendStatus(404);
// });

app.use(function (err, req, res, next) {
    console.error(err.stack);
    if (err.name === 'UnauthorizedError') {
        res.sendStatus(401);
    }
    res.sendStatus(500);
});

var environment = process.env.NODE_ENV;

switch (environment) {
    case 'production':
        console.log("PROD");
        var https = require('https');
        var fs = require('fs');
        var privateKey = fs.readFileSync(__dirname + '/ssl' + '/profeya_pe.key', 'utf8');
        var certificate = fs.readFileSync(__dirname + '/ssl' + '/profeya_pe.crt', 'utf8');
        var credentials = {
            key: privateKey,
            cert: certificate,
            ca: [fs.readFileSync(__dirname + '/ssl' + '/AddTrustExternalCARoot.crt', 'utf8'),
                fs.readFileSync(__dirname + '/ssl' + '/COMODORSAAddTrustCA.crt', 'utf8'),
                fs.readFileSync(__dirname + '/ssl' + '/COMODORSADomainValidationSecureServerCA.crt', 'utf8')]
        };

        var httpsServer = https.createServer(credentials, app);
        httpsServer.listen(80);

        break;
    case 'uat':
        console.log('** UAT **');
        console.log('serving from ' + './app/client/ and ./');
        app.use('/', express.static('./app/client/'));
        app.use('/', express.static('./'));

        var port = 80
        app.listen(port, function () {
            console.log('Express server listening on port ' + port);
            console.log('env = ' + app.get('env') +
                '\n__dirname = ' + __dirname +
                '\nprocess.cwd = ' + process.cwd());
        });
        break;
    default:
        console.log('** DEV **');
        console.log('serving from ' + './app/client/ and ./');
        app.use('/', express.static('./app/client/'));
        app.use('/profe', express.static('./app/profe/'));
        app.use('/admin', express.static('./app/admin/'));
        app.use('/', express.static('./'));

        var port = process.env.PORT || 80;
        app.listen(port, function () {
            console.log('Express server listening on port ' + port);
            console.log('env = ' + app.get('env') +
                '\n__dirname = ' + __dirname +
                '\nprocess.cwd = ' + process.cwd());
        });
        break
}


