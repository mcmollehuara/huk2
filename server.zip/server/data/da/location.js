class LocationDA{
  constructor(){
    var mongoose = require('mongoose');
    var Schema = mongoose.Schema;
    var ObjectId = Schema.ObjectId;

    var LocationSchema = new Schema({

    }, 
      {collection: 'locations'}
    );
    this.model = mongoose.model('Location', LocationSchema);
  }

  getLocations(done){
    this.model.find({}, (err, docs) => {
      return done(err, docs);
    });
  }
}

module.exports = new LocationDA();