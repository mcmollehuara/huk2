var Promise = require("bluebird");

class Role {
    constructor() {
        var mongoose = require('mongoose');
        var Schema = mongoose.Schema;
        var ObjectId = Schema.ObjectId;
        var RoleSchema = new Schema({
            _id: ObjectId,
            type: String,
            entity_id: String
        });
        this.model = mongoose.model('Role', RoleSchema);

        var updateSchema = new Schema({
            _id: ObjectId,
            type: String,
            entity_id: String
        }, { collection: 'role' });

        this.modelUpdate = mongoose.model('UpdateRole', updateSchema);
    }

    getAll(done) {
        this.model.find({}, (err, docs) => {
            return done(err, docs);
        });
    }

    updateRole(role_id, model) {
        return new Promise((resolve, reject) => {
            this.modelUpdate.update({ "_id": role_id }, {
                $set: model
            }, function (err, raw) {
                if (err) {
                    reject(err);
                }
                resolve(raw);
            })
        });
    }

}