var neo4j = require('neo4j');
var config = require('config');
var neo4jConfig = config.get('neo4j');
var db = new neo4j.GraphDatabase(neo4jConfig.url);

class ReviewDA {

  constructor() {
    var mongoose = require('mongoose');
    var Schema = mongoose.Schema;
    var ObjectId = Schema.ObjectId;

    var ServiceSchema = new Schema({
      review: {
        rating: Number,
        text: String,
        posted: Date
      }
    }, {
        collection: 'service'
      });

    this.model = mongoose.model('Review', ServiceSchema);

  }
  createReview(service_id, content) {
    var that = this;
    return new Promise(function (resolve, reject) {
      that.model.update({ "_id": service_id }, {
        $set: {
          review: {
            rating: content.review.rating,
            text: content.review.text,
            posted: new Date()
          }
        }
      }, function (err, raw) {
        if (err) {
          reject(err);
        }
        resolve(raw);
      })
    });
  }

  createRelationUserProfessional(user_id, professional_id) {
    return new Promise(function (resolve, reject) {
      db.cypher({
        query: 'MERGE (a:Professional {id: {professional_id}}) MERGE (b:User {id: {user_id}}) 	MERGE (b)-[:WORK_WITH]->(a)',
        params: {
          professional_id: professional_id,
          user_id: user_id
        },
      }, function (err, results) {
        if (err)
          reject(err);
        resolve();
      });
    })
  }
}

module.exports = new ReviewDA();