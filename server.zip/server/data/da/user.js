var bcrypt = require('bcryptjs');
var Promise = require("bluebird");
var config = require('config');
var neo4j = require('neo4j');
var neo4jConfig = config.get('neo4j');
var db = new neo4j.GraphDatabase(neo4jConfig.url);

class UserDA {
    constructor() {
        var mongoose = require('mongoose');
        var Schema = mongoose.Schema;
        var ObjectId = Schema.ObjectId;

        var UserSchema = new Schema({
            firstName: String,
            lastName: String,
            phone: String,
            local: {
                email: String,
                password: String
            },
            facebook: {
                id: String,
                token: String,
                email: String,
                name: String,
                isSync: String,
                lastChange: Date,
                _json: Schema.Types.Mixed
            }
        }, {
                collection: 'user'
            });

        this.model = mongoose.model('User', UserSchema);
    }

    getUserById(id, done) {
        this.model.findOne({ _id: id }, (err, doc) => {
            if (err) {
                return done(err);
            }
            if (doc) {
                doc.local.password = undefined;
            }
            return done(null, doc);
        });
    }

    getByLocalEmail(email, done) {
        this.model.findOne({ 'local.email': email }, (err, doc) => {
            return done(err, doc);
        });
    }


    getByEmail(email, done) {
        this.model.findOne({ $or: [{ "local.email": email }, { "facebook.email": email }] }, (err, doc) => {
            return done(err, doc);
        });
    }

    createLocalUser(user, done) {
        var salt = bcrypt.genSaltSync(10);
        var hash = bcrypt.hashSync(user.password, salt);
        var newUser = new this.model({
            firstName: user.firstName,
            lastName: user.lastName,
            phone: user.phone,
            local: {
                email: user.email,
                password: hash
            }
        });
        newUser.save((err) => {
            newUser.local.password = undefined;
            return done(err, newUser);
        });
    }

    validateUserPassword(password, hash) {
        return bcrypt.compareSync(password, hash);
    }

    getByFacebookId(id, done) {
        this.model.findOne({ 'facebook.id': id }, (err, doc) => {
            return done(err, doc);
        });
    }

    createFacebookUser(id, token, email, name, _json) {
        var that = this;
        return new Promise(function (resolve, reject) {
            var newUser = new that.model({
                facebook: {
                    id: id,
                    token: token,
                    email: email,
                    name: name,
                    isSync: 'PENDING',
                    lastChange: new Date(),
                    _json: _json
                }
            });
            newUser.save((err) => {
                if (err) {
                    reject(err)
                }
                resolve(newUser);
            });
        })
    }

    getAllUsers(done) {
        this.model.find({}, (err, docs) => {
            return done(err, docs);
        });
    }

    updateUser(user, token, _json) {
        var that = this;
        return new Promise(function (resolve, reject) {
            that.model.update({ "_id": user._id }, {
                $set: {
                    "facebook.email": user.email,
                    "facebook.token": token,
                    "facebook.isSync": 'PENDING',
                    "facebook.lastChange": new Date(),
                    "facebook._json": _json
                }
            }, function (err, raw) {
                if (err) {
                    reject(err);
                }
                resolve(raw);
            })
        });
    }
    // return frinds
    getFriends(user_id, professional_id) {

        console.log("user_id : $user_id, professional_id: $professional_id")
        var db = new neo4j.GraphDatabase(neo4jConfig.url);
        return new Promise(function (resolve, reject) {
            db.cypher({
                query: 'MATCH (p:Professional)<-[:WORK_WITH]-(f:User)-[:IS_FRIEND_OF]-(me:User)  WHERE me.id = {user_id} AND p.id = {professional_id} Return f.id LIMIT 5',
                params: {
                    professional_id: professional_id,
                    user_id: user_id
                },
            }, function (err, results) {
                if (err)
                    reject(err);

                var innerarray = [];
                if (results) {
                    for (var i = 0; i < results.length; i++) {
                        innerarray.push(results[i]["f.id"]);
                    }
                }

                resolve(innerarray);
            });
        })
    }

    getUsers(users) {
        var that = this;
        return new Promise(function (resolve, reject) {
            that.model.find({ '_id': { $in: users } }, (err, docs) => {
                if (err)
                    reject(err);
                resolve(docs);
            });
        })
    }
}

module.exports = new UserDA();