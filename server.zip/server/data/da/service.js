var Promise = require("bluebird");

class ServiceDA {
  constructor() {
    var mongoose = require('mongoose');
    var Schema = mongoose.Schema;
    var ObjectId = Schema.ObjectId;

    var ServiceSchema = new Schema({
      user_id: ObjectId,
      professional_id: ObjectId,
      service_id: Number,
      service_location: String,
      date: String,
      startTime: Number,
      endTime: Number,
      address: String,
      reference: String,
      contactphone: String,
      email: String,
      promotionCode: String,
      status: String,
      payment_status: String,
      latitude: Number,
      longitude: Number,
      created: Date,
      price: Number,
      booking_price: Number,
      service_price: Number,
      total_price: Number
    }, {
        collection: 'service'
      });


    var ServicesConfig = new mongoose.Schema({
      _id: String,
      hour_limit: String,
      contact_email: String,
      bank_BCP: String
    },
      { collection: 'services.config' }
    );

    this.servicesConfigModel = mongoose.model('services.config', ServicesConfig);


    this.model = mongoose.model('Service', ServiceSchema);

    var updateSchema = new Schema({
      _id: ObjectId,
      status: String
    }, { collection: 'service' });

    this.modelUpdate = mongoose.model('UpdateService', updateSchema);

    var CounterSchema = Schema({
      _id: { type: String, required: true },
      seq: { type: Number, default: 0 }
    });
    var counter = mongoose.model('counters', CounterSchema);

    ServiceSchema.pre("save", function (next) {
      var doc = this;
      counter.findByIdAndUpdate({ _id: 'services' }, { $inc: { seq: 1 } }, function (error, counter) {
        if (error)
          return next(error);
        doc.service_id = counter.seq;
        next();
      });
    });

    this.PaymentStatus = {
      Pending: "PENDING"
    }
    this.Status = {
      Pending: "PENDING"
    }
  }
  createInitialService(service, done) {
    this.isProfessionalBusy(service, (err, isBusy) => {
      if (err) {
        return done(err);
      }
      if (isBusy) {
        return done(err, false, 'El profesional seleccionado no tiene disponibilidad en la fecha indicada');
      }
      service.payment_status = this.PaymentStatus.Pending;
      service.status = this.Status.Pending;
      service.created = new Date()

      var newService = new this.model(service);
      
      newService.save((err) => {
        return done(err, newService);
      });
    });
  }

  //db.collection.find({"startdate": {"$lt": E}, "enddate": {"$gt": S}})
  //_.difference(array, [values])

  isProfessionalBusy(service, done) {
    var queryFilter = {
      professional_id: service.professional_id,
      date: service.date
    };
    var queryProjection = {
      startTime: 1,
      endTime: 1
    };
    this.model.find(queryFilter, queryProjection, (err, docs) => {
      if (err) {
        return done(err);
      }
      if (docs.length == 0) {
        return done(null, false);
      }

      var {startTime, endTime} = service;
      var isBusy = false;
      docs.forEach((d) => {
        var tmp = this.checkOverlap(d.startTime, d.endTime, startTime, endTime);
        if (tmp) {
          isBusy = true;
        }
      });
      return done(false, isBusy);
    });
  }
  checkOverlap(startA, endA, startB, endB) {
    return startA < endB && startB < endA;
  }


  getServiceById(service_id) {
    var that = this;
    return new Promise(function (resolve, reject) {
      that.model.findOne({ _id: service_id }, (err, doc) => {
        if (err)
          reject(err)
        resolve(doc);
      });
    })
  }

  updateService(service_id, model) {
    return new Promise((resolve, reject) => {
      this.modelUpdate.update({ "_id": service_id }, {
        $set: model
      }, function (err, raw) {
        if (err) {
          reject(err);
        }
        resolve(raw);
      })
    });
  }
  getConfig(configversion) {
    return new Promise((resolve, reject) => {
      this.servicesConfigModel.findOne({ _id: configversion }, (err, doc) => {
        if (err)
          reject(err)
        resolve(doc);
      })
    });
  }

  //Pupil
  userServiceHistory(user_id, done) {
    this.model.find({ user_id: user_id }).sort({ created: -1 }).exec(function (err, docs) {
      return done(err, docs);
    })
  }

  // Professional/Teacher
  professionalSevices(user_id, done) {
    this.model.find({ professional_id: user_id }).sort({ created: -1 }).exec(function (err, docs) {
      return done(err, docs);
    })
  }

  // Admin
  adminServices(done) {
    this.model.find().sort({ created: -1 }).exec(function (err, docs) {
      return done(err, docs);
    })
  }
}

module.exports = new ServiceDA();