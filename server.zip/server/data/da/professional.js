var async = require('async');
var ServiceDA = require('./service');
var neo4j = require('neo4j');
var Promise = require("bluebird");

class ProfessionalDA {
    constructor() {
        var mongoose = require('mongoose');
        var Schema = mongoose.Schema;
        var ObjectId = Schema.ObjectId;
        var ProfessionalSchema = new Schema({
            name: String,
            dni: String,
            age: Number,
            sex: String,
            birthday: Date,
            email: String,
            cellphone: String,
            whatsapp: String,
            bank: String,
            bank_account: String,
            rating: Number,
            year_of_experience: Number,
            address: String,
            day_prior: Number,
            services_location: [String],
            availability: [Schema.Types.Mixed]
        });
        this.model = mongoose.model('Professional', ProfessionalSchema);
    }
    getDayString(dateOfWeekNumber) {
        var dateOfWeek = "";
        if (dateOfWeekNumber == 0) {
            dateOfWeek = "DOM";
        } else if (dateOfWeekNumber == 1) {
            dateOfWeek = "LUN";
        } else if (dateOfWeekNumber == 2) {
            dateOfWeek = "MAR";
        } else if (dateOfWeekNumber == 3) {
            dateOfWeek = "MIE";
        } else if (dateOfWeekNumber == 4) {
            dateOfWeek = "JUE";
        } else if (dateOfWeekNumber == 5) {
            dateOfWeek = "VIE";
        } else if (dateOfWeekNumber == 6) {
            dateOfWeek = "SAB";
        }
        return dateOfWeek;
    }

    getAll(done) {
        this.model.find({}, (err, docs) => {
            return done(err, docs);
        });
    }

    getById(id) {
        var that = this;
        return new Promise(function (resolve, reject) {
            that.model.findOne({ _id: id }, (err, doc) => {
                if (err)
                    reject(err);
                resolve(doc);
            });
        })
    }

    getBySearch(filter, done) {
        var {
            place,
            date,
            startTime,
            endTime
        } = filter;
        //date get day of week
        var dateParts = date.split("-");
        var dateObj = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);
        var dateOfWeekNumber = dateObj.getDay();
        var dateOfWeek = this.getDayString(dateOfWeekNumber);

        var queryFilter = {
            services_location: {
                $in: [place]
            },
            "availability.hours": {
                $in: [Number(startTime), Number(endTime)]
            },
            "availability.day": {
                $in: [dateOfWeek]
            }
        };
        var queryProjection = {
            _id: 1,
            name: 1,
            first_name: 1,
            last_name: 1,
            dni: 1,
            sex: 1,
            price: 1,
            year_of_experience: 1,
            skills: 1
        };

        var hours = Number(endTime) - Number(startTime);

        console.log(queryFilter);

        this.model.aggregate([{
            $match: {
                'services_location': {
                    $in: [place]
                },
                'availability.hours': {
                    $in: [Number(startTime), Number(endTime)]
                },
                'availability.day': {
                    $in: [dateOfWeek]
                }
            }
        }, {
                $lookup: {
                    from: 'service',
                    localField: '_id',
                    foreignField: 'professional_id',
                    as: 'services_doc'
                }
            }, {
                $project: {
                    _id: 1,
                    rating: {
                        $avg: "$services_doc.review.rating"
                    },
                    reviews: { $size: "$services_doc.review" },
                    services: { $size: "$services_doc" },
                    name: 1,
                    first_name: 1,
                    last_name: 1,
                    dni: 1,
                    sex: 1,
                    price: {
                        $multiply: ["$price", hours * (1.2)]
                    },
                    year_of_experience: 1,
                    skills: 1,
                    picture: 1
                }
            }
        ], (err, docs) => {
            if (err) {
                return done(err);
            }
            if (docs.length == 0) {
                return done(null, []);
            }
            async.filter(docs, function (professional, callback) {
                ServiceDA.isProfessionalBusy({
                    professional_id: professional._id,
                    date: date,
                    startTime: startTime,
                    endTime: endTime
                }, function (err, isBusy) {
                    return callback(err, !isBusy);
                });
            },
                function (err, results) {
                    return done(err, results);
                }
            );

        });
    }
}

module.exports = new ProfessionalDA();
