var bcrypt = require('bcryptjs');
var Promise = require("bluebird");
var config = require('config');

class AdminDA {
  constructor() {
    var mongoose = require('mongoose');
    var Schema = mongoose.Schema;
    var ObjectId = Schema.ObjectId;

    var AdminSchema = new Schema({
      firstName: String,
      lastName: String,
      phone: String,
      email: String,
      password: String
    }, {
        collection: 'admin'
      });

    this.model = mongoose.model('Admin', AdminSchema);
  }

  createAdmin(user, done) {
    var salt = bcrypt.genSaltSync(10);
    var hash = bcrypt.hashSync(user.password, salt);
    var newAdmin = new this.model({
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
      email: user.email,
      password: hash
    });
    newAdmin.save((err) => {
      newAdmin.password = undefined;
      return done(err, newAdmin);
    });
  }

  updateAdmin(user, token, _json) {
    var that = this;
    return new Promise(function (resolve, reject) {
      that.model.update({ "_id": user._id }, {
        $set: user
      }, function (err, raw) {
        if (err) {
          reject(err);
        }
        resolve(raw);
      })
    });
  }
  
  getById(id, done) {
    this.model.findOne({ _id: id }, (err, doc) => {
      if (err) {
        return done(err);
      }
      if (doc) {
        doc.password = undefined;
      }
      return done(null, doc);
    });
  }

  getAll(done) {
    this.model.find({}, (err, docs) => {
      docs.forEach(function (element) {
        element.password = undefined;
      }, this);
      return done(err, docs);
    });
  }
}

module.exports = new AdminDA();