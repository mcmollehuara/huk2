class Repository{
  constructor(){    
    return {
      UserDA: require('./da/user'),
      LocationDA: require('./da/location'),
      ProfessionalDA: require('./da/professional'),
      ServiceDA: require('./da/service'),
      ReviewDA:require('./da/review'),
    }    
  }
}

module.exports = new Repository();
