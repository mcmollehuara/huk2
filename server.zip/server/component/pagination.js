class Pagination{
  constructor(){
    this.pageSize = 25;    
  }
  paginate(data, page = 1){
    var pagination = {
      data: [],
      current: 0,
      pages: 0,
      total: 0
    };
    var total = data.length;
    if(total){      
      pagination.current = Number(page);
      pagination.pages = Math.ceil(total / this.pageSize);
      pagination.total = total;
      var skip = (page - 1) * this.pageSize;
      pagination.data = data.slice(skip, skip + this.pageSize);
    }
    return pagination;
  }
}

module.exports = new Pagination();