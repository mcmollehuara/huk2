// var nodemailer = require('nodemailer');

class EmailDispatch {
  constructor() {
    var config = require('config');
    // this.emailConfig = config.get('zohosmtp');
    this.emailConfig = config.get('sendgrid');

    // this.senderAddress = this.emailConfig.senderAddress;
    this.reactmail = require("./reactmail");
    this.reactWelcomeEmail = require("./reactWelcomeEmail");

    var mongoose = require('mongoose');
    var Schema = mongoose.Schema;
    var ObjectId = Schema.ObjectId;
    var EmailTemplateSchema = new Schema({
      code: String,
      template: String,
      fields: [String],
      subject: String
    }, { collection: 'emailTemplate' });
    this.model = mongoose.model('EmailTemplate', EmailTemplateSchema);
  }

  sendOrderMail(service, config, professional, email, done) {

    // var sendgrid = require("sendgrid")(this.emailConfig.key);
    // var html = this.reactmail.processtemplate(service, professional, config);
    // var email = new sendgrid.Email();
    // email.addTo(email);
    // email.setFrom(this.emailConfig.senderAddress);
    // email.setSubject("Recibo de tu pedido en profeya.pe order # " + service.service_id);
    // email.setHtml(html);

    // sendgrid.send(email);
    // console.log("Recibo de tu pedido en profeya.pe order # " + service.service_id);

    var html = this.reactmail.processtemplate(service, professional, config);
    var sg = require('sendgrid')(this.emailConfig.key);
     var helper = require('sendgrid').mail
    var request = sg.emptyRequest({
      method: 'POST',
      path: '/v3/mail/send',
      body: {
        personalizations: [
          {
            to: [
              {
                email: email,
              },
            ],
            subject: "Recibo de tu pedido en profeya.pe order # " + service.service_id,
            html: html
          },
        ],
        from: {
          email: this.emailConfig.senderAddress,
        },
        content: [
          {
            type: 'text/html',
            value: html,
          },
        ],
      },
    });
    //With promise
    sg.API(request)
      .then(response => {
        console.log(response.statusCode);
        console.log(response.body);
        console.log(response.headers);
      })
      .catch(error => {
        console.log(error.response.statusCode);
      });
  }

  sendNewUserMail(user, email, done) {
    var html = this.reactWelcomeEmail.processtemplate(user);
    var sg = require('sendgrid')(this.emailConfig.key);
     var helper = require('sendgrid').mail
    var request = sg.emptyRequest({
      method: 'POST',
      path: '/v3/mail/send',
      body: {
        personalizations: [
          {
            to: [
              {
                email: email,
              },
            ],
            subject: "Bienvenido a profeya.pe",
            html: html
          },
        ],
        from: {
          email: this.emailConfig.senderAddress,
        },
        content: [
          {
            type: 'text/html',
            value: html,
          },
        ],
      },
    });
    //With promise
    sg.API(request)
      .then(response => {
        console.log(response.statusCode);
        console.log(response.body);
        console.log(response.headers);
      })
      .catch(error => {
        console.log(error.response.statusCode);
      });

  }
}

module.exports = new EmailDispatch();