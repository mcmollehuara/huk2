var React = require("react");
var reactDomServer = require("react-dom/server")
var juice = require("juice")
var fs = require("fs");

class WelcomeEmail extends React.Component {
    render() {
        return (
            <html>
                <body>
                    <table className="body-wrap">
                        <tbody>
                            <tr>
                                <td>
                                </td>
                                <td className="container" width="600">
                                    <div className="content">
                                        <table className="main" width="100%" cellPadding="0" cellSpacing="0">
                                            <tbody><tr>
                                                <td className="content-wrap aligncenter">
                                                    <table width="100%" cellPadding="0" cellSpacing="0">
                                                        <tbody>
                                                            <tr>
                                                                <td className="content-block">
                                                                    <h2> Bienvenido a Profeya</h2>                                                                    
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    Estimado/a {this.props.user.first_name} {this.props.user.last_name}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    Muchas gracias por elegir Profeya
                                                                    Puedes dirigirte a la siguiente direccion {this.props.user.url}/#/confirmation 
                                                                    e ingresar el siguiente codigo de confirmacion:
                                                                    {this.props.user.encrypted}                                                                    
                                                                    <br/>Profeya es un lugar donde puede encontrar profesionales de la enseñanza.
                                                                    Es importante mencionarle que las personas que trabajan con nosotros han pasado por un estricto sistema de evaluación
                                                                    <br/>Si tiene alguna duda que envien un correo a contacto@profeya.pe
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                </td>
                                            </tr>
                                            </tbody></table>
                                        <div className="footer">
                                            <table width="100%">
                                                <tbody><tr>
                                                    <td className="aligncenter content-block">email <a href="mailto:">contacto@profeya.pe</a></td>
                                                </tr>
                                                </tbody></table>
                                        </div></div>
                                </td>
                                <td></td>
                            </tr>
                        </tbody></table>
                </body>
            </html>
        )
    }
}


class ReactWelcomeEmail {
    processtemplate(user) {
        var cssfile = fs.readFileSync(__dirname + "/css/style.css", { encoding: "utf8" })
        var html = juice.inlineContent(reactDomServer.renderToStaticMarkup(<WelcomeEmail user={user}/>), cssfile);
        return html;
    }
}

module.exports = new ReactWelcomeEmail();