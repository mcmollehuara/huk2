var React = require("react");
var reactDomServer = require("react-dom/server")
var juice = require("juice")
var fs = require("fs");

class DigestEmail extends React.Component {

    render() {

        return (
            <html>
                <body>
                    <table className="body-wrap">
                        <tbody>
                            <tr>
                                <td></td>
                                <td className="container" width="600">
                                    <div className="content">
                                        <table className="main" width="100%" cellPadding="0" cellSpacing="0">
                                            <tbody>
                                                <tr>
                                                    <td className="content-wrap">
                                                        <table width="100%" cellPadding="0" cellSpacing="0">
                                                            <tr>
                                                                <td className="content-block aligncenter">
                                                                    <h2>Gracias por usar Profeya</h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Order #{this.props.service.service_id}
                                                                    <br/>{this.props.service.date} @{this.props.service.startTime} - {this.props.service.endTime}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    Para tu información, los detalles del pedido son los siguientes.
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    Para confirmar la reserva de tu servicio, realiza el pago de “Reserva de Servicio” a la cuenta BCP antes de la fecha: {this.props.config.date_limit} {this.props.config.hour_limit} am y envíanos un e-mail a contacto @profeya.pe indicando el número de Orden del servicio y el Nro de Operación bancaria del pago.
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    Cuenta BCP: ###-#######-#-##
                                                                    <br/>El pago del “Servicio de Enseñanaza lo realizarás directamente a la trabajadora una vez que el servicio se haya culminado.
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    <table className="invoice">
                                                                        <tr>
                                                                            <td>
                                                                                <table className="invoice-items" cellPadding="0" cellSpacing="0">
                                                                                    <tr>
                                                                                        <td>Reserva de Servicio	</td>
                                                                                        <td className="alignright">S/.{this.props.service.booking_price}</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td>Servicios</td>
                                                                                        <td className="alignright">S/.{this.props.service.service_price}</td>
                                                                                    </tr>
                                                                                    <tr className="total">
                                                                                        <td className="alignright" width="80%">Total</td>
                                                                                        <td className="alignright">S/.{this.props.service.total_price}</td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block">
                                                                    Información de nuestra colaboradora:
                                                                    <br/>
                                                                    <br/> Nombre: {this.props.professional.name}
                                                                    <br/> DNI: {this.props.professional.dni}
                                                                    <br/> Celular: {this.props.professional.cellphone}
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td className="content-block aligncenter">
                                                                    Profeya atencion al cliente
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div className="footer">
                                            <table width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td className="aligncenter content-block">email <a href="mailto:">contacto @profeya.pe</a></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </body>
            </html>
        )
    }
}

class Template {

    processtemplate(service_data, professional, config) {
        var cssfile = fs.readFileSync(__dirname + "/css/style.css", { encoding: "utf8" })
        var html = juice.inlineContent(reactDomServer.renderToStaticMarkup(<DigestEmail service={service_data} config ={config} professional={professional} />), cssfile);
        return html;
    }
}

module.exports = new Template();