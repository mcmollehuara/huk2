var moment = require('moment');


class ServiceRoute {
    constructor(authenticate) {
        var schemaValidation = require('../../schemaValidation'),
            express = require('express'),
            router = express.Router(),
            ProfessionalDA = require('../../data').ProfessionalDA,
            ServiceDA = require('../../data').ServiceDA,
            ReviewDA = require('../../data').ReviewDA,
            Pagination = require('../../component/pagination'),
            emailDispatch = require('../../component/emailDispatch');

        var _util = new ServiceUtil();

        /**
        * @api {get} /api/services Request services available using filter
        * @apiName GetServicesByFilter
        * @apiGroup services  
        *
        * @apiParam (queryString) {String} place Distrito
        * @apiParam (queryString) {Number} startTime Hora de inicio (0-24)
        * @apiParam (queryString) {Number} endTime Hora de fin (0-24)
        * @apiParam (queryString) {String} date Fecha del servicio requerido (YYYY-MM-DD)
        * @apiParam (queryString) {String} [page] Página
        * @apiSampleRequest http://localhost:8080/api/services?place=Miraflores&startTime=8&endTime=12&date=2016-05-30&page=1
        * @apiSuccessExample {json} Success-Response:
        *     HTTP/1.1 200 OK
        *   {
            "data":[
            {
            "_id": "5739efddf9bfb5dba2524a0f",
            "name": "Wendy Marisol Condori Poma",
            "dni": "46160356",
            "sex": "F",
            "year_of_experience": 4
            }
            ],
            "current": 1,
            "pages": 1,
            "total": 1
            }
        */
        router.get('/', schemaValidation.serviceSearch(), (req, res) => {
            ProfessionalDA.getBySearch(req.query, (err, docs) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                var data = Pagination.paginate(docs, req.query.page);
                return res.json(data);
            });
        });

        router.get("/:service_id", authenticate, (req, res) => {

            var service_id = req.params.service_id;
            ServiceDA.getServiceById(service_id)
                .then(function (service) {
                    return res.json(service);
                }).catch(function (err) {
                    return res.sendStatus(500);
                })
        });

        router.put("/:service_id", schemaValidation.updateServiceSchema(), (req, res) => {
            var service_id = req.params.service_id;
            console.log(req.body);

            ServiceDA.updateService(service_id, req.body)
                .then(function (raw) {
                    return ServiceDA.getServiceById(service_id);
                })
                .then(function (service) {
                    return res.json(service);
                })
                .catch(function (err) {
                    return res.sendStatus(500);
                })
        });

        router.post('/', authenticate, schemaValidation.serviceCreation(), (req, res) => {
            req.body.user_id = req.user.id;
            ServiceDA.createInitialService(req.body, (err, doc, info) => {
                if (err) {
                    return res.sendStatus(500);
                }
                if (!doc) {
                    return res.status(400).json({
                        message: info
                    });
                }

                var config = {};

                ServiceDA.getConfig('CONFIGV1')
                    .then(function (config) {

                        var plainConfig = config.toObject()

                        var onedaybefore = _util.getyesterday(doc.date);

                        plainConfig.date_limit = onedaybefore;

                        config = plainConfig

                        return ProfessionalDA.getById(doc.professional_id)

                    })
                    .then(function (professional) {

                        emailDispatch.sendOrderMail(doc, config, professional, req.user.email, (err, result) => { });
                        
                        return res.json(doc);
                    })
                    .catch(function (err) {

                        console.log(err);

                        return res.json(doc);
                    })
            });
        });

        router.post("/:service_id/review", authenticate, schemaValidation.reviewCreationSchema(), (req, res) => {
            var user_id = req.user.id;
            var service_id = req.params.service_id;
            ReviewDA.createReview(service_id, req.body)
                .then(function (raw) {
                    return ServiceDA.getServiceById(service_id)
                })
                .then(function (service) {
                    return ReviewDA.createRelationUserProfessional(user_id, service.professional_id.toString())
                })
                .then(function () {
                    return res.json({ isOk: true });
                })
                .catch(function (err) {
                    return res.sendStatus(500);
                })
        });

        router.get("/:service_id/confirmation", authenticate, (req, res) => {
            var user_id = req.user.id;
            var service_id = req.params.service_id;

            var confirmation = {};

            ServiceDA.getConfig("CONFIGV1")
                .then((config) => {
                    confirmation.config = config;
                    return ServiceDA.getServiceById(service_id)

                }).then((service) => {
                    var onedaybefore = _util.getyesterday(service.date);
                    console.log(onedaybefore);
                    confirmation.config._doc.date_limit = onedaybefore;
                    confirmation.service = service;
                    return res.json(confirmation);
                })
                .catch((err) => {
                    console.log(err);
                    res.sendStatus(500);
                })
        });

        return router;
    }
}

class ServiceUtil {
    getyesterday(date) {
        return moment(date, "YYYY-MM-DD").add(-1, 'days').format("YYYY-MM-DD")
    }
}


module.exports = function (authenticate) {
    return new ServiceRoute(authenticate);
}