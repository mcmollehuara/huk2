class AdminRoute {
    constructor() {
        var express = require('express'),
            router = express.Router(),
            adminDA = require('../../data').AdminDA;

        router.get('/', (req, res) => {
            adminDA.getAll((err, docs) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                return res.json(docs);
            });
        });

        router.get('/:id', (req, res) => {
            var id = req.params.id;
            adminDA.getById(id)
                .then(function (docs) {
                    return res.json(docs)
                })
                .catch(function (err) {
                    return res.sendStatus(500);
                });
        });

        router.post((req, res) => {
            UserDA.getByLocalEmail(email, (err, user) => {
                if (err) {
                    return done(err);
                }
                if (user) {
                    return done(null, false, "El email ya esta siendo usado");
                }
                UserDA.createLocalUser(req.body, (err, newUser) => {
                    if (err) {
                        throw err;
                    }
                    console.log("before email");


                    var _user = {
                        id: newUser._id,
                        email: email,
                        first_name: newUser.firstName,
                        last_name: newUser.lastName,
                        url: config.get("siteInfo").url,
                        encrypted: req.body.encrypted
                    };

                    emailcomponent.sendNewUserMail(_user, email, true);
                    console.log("after email");
                    return done(null, { id: newUser._id, email: email, name: newUser.firstName + " " + newUser.lastName });
                });
            });
        });

        //Services
        router.get('/orders', authenticate, (req, res) => {
            var id = req.user.id;
            ServiceDA.adminServices(id, (err, docs) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                var data = Pagination.paginate(docs, req.query.page);
                return res.json(data);
            });
        });
        
        return router;
    }
}


module.exports = new AdminRoute(); 