class Admin {
    constructor(authenticate) {
        var express = require('express');
        var router = express.Router();

        router.get('/:admin_id', (req, res) => {
            var professionalDA = require('../../data').ProfessionalDA;
            var profesional_id = req.params.profesional_id;

            professionalDA.getById(profesional_id)
                .then(function (profesional) {
                    return res.json(profesional)
                })
                .catch(function (err) {
                    return res.sendStatus(500);
                })
        });

        //Services 
        router.get('/:profesional_id/services', authenticate, (req, res) => {
            var serviceDA = require('../../data').ServiceDA;
            var id = req.user.id;
            serviceDA.professionalServices(id, (err, docs) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                var data = Pagination.paginate(docs, req.query.page);
                return res.json(data);
            });
        });

        return router;
    }
}

module.exports = function (authenticate) {
    return new Professionals(authenticate);
}