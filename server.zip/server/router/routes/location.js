class LocationRoute{
  constructor(){
  var express = require('express'),
    router = express.Router(),
    LocationDA = require('../../data').LocationDA;

    router.get('/', (req, res) => {
      LocationDA.getLocations((err, docs) => {
        if(err){
          console.log(err);
          return res.sendStatus(500);
        }
        return res.json(docs);
      });
    });

    return router;
  }
}

module.exports = new LocationRoute();