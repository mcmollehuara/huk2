class UserRoute {
    constructor(authenticate) {
        var schemaValidation = require('../../schemaValidation');
        var express = require('express'),
            router = express.Router(),
            UserDA = require('../../data').UserDA,
            ServiceDA = require('../../data').ServiceDA,
            Pagination = require('../../component/pagination');

        router.get('/me', authenticate, (req, res) => {
            var id = req.user.id;
            UserDA.getUserById(id, (err, result) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                return res.json(result);
            });
        });

        router.get('/me/history', authenticate, (req, res) => {
            var id = req.user.id;
            ServiceDA.userServiceHistory(id, (err, docs) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                var data = Pagination.paginate(docs, req.query.page);
                return res.json(data);
            });
        });

        router.get('/me/friends', authenticate, function (req, res) {
            //professional=:professional_id
            var {professional} = req.query;
            var user_id = req.user.id;

            UserDA.getFriends(user_id, professional)
                .then(function (friends) {
                    if (friends.length > 0) {
                        return UserDA.getUsers(friends);
                    }
                    else {
                        return [];
                    }
                })
                .then(function (users) {
                    return res.json(users);
                })
                .catch(function (err) {
                    return res.sendStatus(500);
                })
        })
        return router;
    }
}

module.exports = function (authenticate) {
    return new UserRoute(authenticate);
} 