class Router {
    constructor(app, passport) {
        const secretTokenKeyword = "server secret";
        const expirationSeconds = 7200; //2 hours

        var path = require('path');
        var jwt = require('jsonwebtoken');
        var expressJwt = require('express-jwt');
        var authenticate = expressJwt({ secret: secretTokenKeyword });
        var schemaValidation = require('../schemaValidation');

        var config = require('config');

        function createTokenRedirect(req, res) {
            console.log("createTokenRedirect", req.user)
            req.token = jwt.sign({
                id: req.user.id,
                email: req.user.email
            }, secretTokenKeyword, { expiresIn: expirationSeconds });
            var redirect = `?token=${req.token}`;
            res.redirect(config.get('profeya.TokenRedirect') + redirect);
            //res.redirect('http://localhost:7200/channel.html' + redirect);
            return res;
        }
        function createTokenSend(req, res) {
            console.log("createTokenSend", req.user)
            var token = jwt.sign({
                id: req.user.id,
                email: req.user.email
            }, secretTokenKeyword, { expiresIn: expirationSeconds });
            return res.json({ token: token });
        }

        //Local
        app.post('/auth/signup', (req, res, next) => {
            passport.authenticate('local-signup', (err, user, info) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                if (!user) {
                    return res.status(400).json({ message: info });
                }



                req.user = user;
                return next();
            })(req, res, next);
        }, createTokenSend);

        app.post('/auth/login', (req, res, next) => {
            passport.authenticate('local-login', (err, user, info) => {
                if (err) {
                    console.log(err);
                    return res.sendStatus(500);
                }
                if (!user) {
                    return res.status(400).json({ message: info });
                }
                req.user = user;
                return next();
            })(req, res, next);
        }, createTokenSend);

        //Facebook
        app.get('/auth/facebook', passport.authenticate('facebook', { scope: ['user_friends', 'email',] }));

        app.get('/auth/facebook/callback', passport.authenticate('facebook', {
            session: false
        }), createTokenRedirect);

        //API routes
        app.use('/api/user', require('./routes/user')(authenticate));        
        app.use('/api/locations', require('./routes/location'));
        app.use('/api/services', require('./routes/service')(authenticate));
        app.use('/api/professionals', require('./routes/professionals')(authenticate));
    }
}

module.exports = function (app, passport) {
    new Router(app, passport);
}