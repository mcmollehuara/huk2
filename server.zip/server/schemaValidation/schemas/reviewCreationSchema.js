class ReviewCreationSchema{
  constructor(){
    var Joi = require('joi');
    var schema = Joi.object({        
        review :{
            rating : Joi.number().required(),   
            text : Joi.string().required()     
        }        
    });
    return schema;
  }
}

module.exports = new ReviewCreationSchema();