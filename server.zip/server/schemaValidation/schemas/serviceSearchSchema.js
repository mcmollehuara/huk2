class ServiceSearchSchema{
  constructor(){
    var Joi = require('joi');
    var schema = Joi.object({
      place: Joi.string().required(),
      startTime: Joi.number().required(),
      endTime: Joi.number().required(),
      date: Joi.date().format("YYYY-MM-DD").required(),
      page: Joi.number()    
    });
    return schema;
  }
}

module.exports = new ServiceSearchSchema();