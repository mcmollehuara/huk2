class UserCreationSchema{
  constructor(){
    var Joi = require('joi');
    var schema = Joi.object({
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      phone: Joi.string().required(),
      email: Joi.string().required().email(),
      password: Joi.string().required()
    });
    return schema;
  }
}

module.exports = new UserCreationSchema();