class ServiceCreationSchema{
  constructor(){
    var Joi = require('joi');
    var schema = Joi.object({
        professional_id : Joi.string().required(),
        service_location : Joi.string().required(),          
        date : Joi.date().format("YYYY-MM-DD").required(),
        startTime : Joi.number().required(),
        endTime : Joi.number().required(),
        address : Joi.string().required(),
        reference : Joi.string().required(),
        contactphone : Joi.string().required(),
        email : Joi.string().required().email(),
        promotionCode: Joi.string().allow('').allow(null),
        latitude: Joi.number().optional().allow(null),
        longitude: Joi.number().optional().allow(null),
        price: Joi.number().required(),
        booking_price: Joi.number().required(),
        service_price : Joi.number().required(),
        total_price : Joi.number().required()
    });
    return schema;
  }
}

module.exports = new ServiceCreationSchema();