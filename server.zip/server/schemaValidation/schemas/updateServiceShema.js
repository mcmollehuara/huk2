class UpdateServiceShema{
  constructor(){
    var Joi = require('joi');
    var schema = Joi.object({        
          status: Joi.string().required(),       
    });
    return schema;
  }
}

module.exports = new UpdateServiceShema();