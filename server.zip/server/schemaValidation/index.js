class SchemaValidation {
  constructor() {
    var Joi = require('joi');
    var userCreationSchema = require('./schemas/userCreationSchema');
    var serviceSearchSchema = require('./schemas/serviceSearchSchema');
    var serviceCreationSchema = require('./schemas/serviceCreationSchema');
    var reviewCreationSchema = require('./schemas/reviewCreationSchema');
    var updateServiceShema = require('./schemas/updateServiceShema');

    return {
      userCreation: () => {
        return (req, res, next) => {
          var data = req.body;
          Joi.validate(data, userCreationSchema, (err, value) => {
            if (err) {
              return res.status(400).json(err.details);
            }
            return next();
          });
        }
      },
      serviceSearch: () => {
        return (req, res, next) => {
          var data = req.query;
          Joi.validate(data, serviceSearchSchema, (err, value) => {
            if (err) {
              return res.status(400).json({ error: err.details });
            }
            return next();
          });
        }
      },
      serviceCreation: () => {
        return (req, res, next) => {
          var data = req.body;
          Joi.validate(data, serviceCreationSchema, (err, value) => {
            if (err) {
              return res.status(400).json({ error: err });
            }
            return next();
          });
        }
      },
      reviewCreationSchema: () => {
        return (req, res, next) => {
          var data = req.body;
          Joi.validate(data, reviewCreationSchema, (err, value) => {
            if (err) {
              return res.status(400).json({ error: err });
            }
            return next();
          });
        }
      },
      updateServiceSchema: () => {
        return (req, res, next) => {
          var data = req.body;
          Joi.validate(data, updateServiceShema, (err, value) => {
            if (err) {
              return res.status(400).json({ error: err });
            }
            return next();
          });
        }
      }
    }
  }
}

module.exports = new SchemaValidation();