exports.HmrState = function() {

};
